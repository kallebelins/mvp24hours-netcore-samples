using $ext_safeprojectname$.Application.Logic;
using $ext_safeprojectname$.Application.Pipe.Builders;
using $ext_safeprojectname$.Core.Contract.Logic;
using $ext_safeprojectname$.Core.Contract.Pipe.Builders;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class ServiceBuilderExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyServices(this IServiceCollection services)
        {
            services.AddScoped<ICustomerService, CustomerService>();

            // pipeline - builders
            services.AddScoped<IGetByCustomerBuilder, GetByCustomerBuilder>();
            services.AddScoped<IGetByIdCustomerBuilder, GetByIdCustomerBuilder>();

            return services;
        }
    }
}
