using Mvp24Hours.Core.Contract.Application.Pipe.Async;

namespace $safeprojectname$.Contract.Pipe.Builders
{
    public interface IGetByCustomerBuilder : IPipelineBuilderAsync
    {
    }
}
