using $safeprojectname$.Entities;
using FluentValidation;

namespace $safeprojectname$.Validations.Customers
{
    public class CustomerValidator : AbstractValidator<Customer>
    {
        public CustomerValidator()
        {
            RuleFor(x => x.Name)
                .NotEmpty()
                .WithMessage("Customer {PropertyName} is required.");

            RuleForEach(x => x.Contacts)
                .SetValidator(new ContactValidator());
        }
    }
}
