using $safeprojectname$.Enums;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class ContactIdResult
    {
        public ContactType Type { get; set; }
        public string Description { get; set; }
    }
}
