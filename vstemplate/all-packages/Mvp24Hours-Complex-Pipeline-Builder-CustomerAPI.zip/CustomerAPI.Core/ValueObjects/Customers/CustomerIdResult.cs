using System.Collections.Generic;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class CustomerIdResult : CustomerResult
    {
        public IList<ContactIdResult> Contacts { get; set; }
    }
}
