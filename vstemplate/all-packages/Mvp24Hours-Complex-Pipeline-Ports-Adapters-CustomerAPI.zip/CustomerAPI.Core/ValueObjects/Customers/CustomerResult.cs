namespace $safeprojectname$.ValueObjects.Customers
{
    public class CustomerResult
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
