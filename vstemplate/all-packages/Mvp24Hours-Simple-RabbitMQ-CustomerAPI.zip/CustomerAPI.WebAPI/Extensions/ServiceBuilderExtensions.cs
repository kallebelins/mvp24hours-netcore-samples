using $ext_safeprojectname$.Application.Brokers.Consumers;
using $ext_safeprojectname$.Application.Logic;
using $ext_safeprojectname$.Core.Contract.Logic;
using $ext_safeprojectname$.Core.Entities;
using $ext_safeprojectname$.Core.Validations.Customers;
using $ext_safeprojectname$.Infrastructure.Data;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mvp24Hours.Core.Enums.Infrastructure;
using Mvp24Hours.Core.Extensions;
using Mvp24Hours.Extensions;
using Mvp24Hours.Helpers;
using Mvp24Hours.Infrastructure.RabbitMQ;
using Mvp24Hours.Infrastructure.RabbitMQ.Configuration;
using NLog;
using System;
using System.Linq;

namespace $safeprojectname$.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class ServiceBuilderExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CustomerDBContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("CustomerDbContext"))
            );
            services.AddMvp24HoursDbContext<CustomerDBContext>();
            services.AddMvp24HoursRepositoryAsync(options =>
            {
                options.MaxQtyByQueryPage = 100;
                options.TransactionIsolationLevel = System.Transactions.IsolationLevel.ReadCommitted;
            });
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyHealthChecks(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddHealthChecks()
                .AddSqlServer(
                    configuration.GetConnectionString("CustomerDbContext"),
                    healthQuery: "SELECT 1;",
                    name: "SqlServer",
                    failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Degraded)
                .AddRabbitMQ(
                    configuration.GetConnectionString("RabbitMQContext"),
                    name: "RabbitMQ",
                    failureStatus: Microsoft.Extensions.Diagnostics.HealthChecks.HealthStatus.Degraded);
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyTelemetry(this IServiceCollection services)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
#if DEBUG
            services.AddMvp24HoursTelemetry(TelemetryLevel.Information | TelemetryLevel.Verbose,
                (name, state) =>
                {
                    if (name.EndsWith("-object"))
                    {
                        logger.Info($"{name}|body:{state.ToSerialize()}");
                    }
                    else
                    {
                        logger.Info($"{name}|{string.Join("|", state)}");
                    }
                }
            );
#endif
            services.AddMvp24HoursTelemetry(TelemetryLevel.Error,
                (name, state) =>
                {
                    if (name.EndsWith("-failure"))
                    {
                        logger.Error(state.ElementAtOrDefault(0) as Exception);
                    }
                    else
                    {
                        logger.Error($"{name}|{string.Join("|", state)}");
                    }
                }
            );
            services.AddMvp24HoursTelemetryIgnore("rabbitmq-consumer-basic");
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyServices(this IServiceCollection services)
        {
            services.AddScoped<ICustomerService, CustomerService>();
            services.AddSingleton<IValidator<Customer>, CustomerValidator>();
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyRabbitMQ(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddMvp24HoursRabbitMQ(
                typeof(CreateCustomerConsumer).Assembly,
                connectionOptions =>
                {
                    connectionOptions.ConnectionString = configuration.GetConnectionString("RabbitMQContext");
                    connectionOptions.DispatchConsumersAsync = true;
                    connectionOptions.RetryCount = 3;
                },
                clientOptions =>
                {
                    clientOptions.Exchange = "customer.direct";
                    clientOptions.MaxRedeliveredCount = 1;
                    clientOptions.QueueArguments = new System.Collections.Generic.Dictionary<string, object>
                    {
                        { "x-queue-mode", "lazy" },
                        { "x-dead-letter-exchange", "dead-letter-customer.direct" }
                    };

                    // dead letter exchanges enabled
                    clientOptions.DeadLetter = new RabbitMQOptions()
                    {
                        Exchange = "dead-letter-customer.direct",
                        QueueArguments = new System.Collections.Generic.Dictionary<string, object>
                        {
                            { "x-queue-mode", "lazy" }
                        }
                    };
                }
            );
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyHostedService(this IServiceCollection services)
        {
            services.AddMvp24HoursHostedService(options =>
            {
                options.Callback = e =>
                {
                    if (ServiceProviderHelper.IsReady())
                    {
                        var client = ServiceProviderHelper.GetService<MvpRabbitMQClient>();
                        client?.Consume();
                    }
                };
            });
            return services;
        }


    }
}
