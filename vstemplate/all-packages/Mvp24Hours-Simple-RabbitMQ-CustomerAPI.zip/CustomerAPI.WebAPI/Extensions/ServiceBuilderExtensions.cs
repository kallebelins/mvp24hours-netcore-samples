using $ext_safeprojectname$.Application.Brokers.Consumers;
using $ext_safeprojectname$.Application.Brokers.Producers;
using $ext_safeprojectname$.Application.Logic;
using $ext_safeprojectname$.Core.Contract.Logic;
using $ext_safeprojectname$.Core.Entities;
using $ext_safeprojectname$.Core.Validations.Customers;
using $ext_safeprojectname$.Core.ValueObjects.Customers;
using $ext_safeprojectname$.Infrastructure.Data;
using FluentValidation;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Mvp24Hours.Extensions;
using Mvp24Hours.Helpers;
using Mvp24Hours.Infrastructure.RabbitMQ.Core.Contract;

namespace $safeprojectname$.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class ServiceBuilderExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyDbContext(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<CustomerDBContext>(options =>
                options.UseMySQL(configuration.GetConnectionString("CustomerDbContext")));
            services.AddMvp24HoursDbServiceAsync<CustomerDBContext>();
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyServices(this IServiceCollection services)
        {
            services.AddScoped<ICustomerService, CustomerService>();
            services.AddSingleton<IValidator<Customer>, CustomerValidator>();
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyRabbitProducer(this IServiceCollection services)
        {
            services.AddScoped<IMvpRabbitMQProducer<CreateCustomerRequest>, CreateCustomerProducer>();
            services.AddScoped<IMvpRabbitMQProducer<UpdateCustomerRequest>, UpdateCustomerProducer>();
            services.AddScoped<IMvpRabbitMQProducer<DeleteCustomerRequest>, DeleteCustomerProducer>();
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyRabbitConsumer(this IServiceCollection services)
        {
            services.AddScoped<IMvpRabbitMQConsumerAsync<CreateCustomerRequest>, CreateCustomerConsumerAsync>();
            services.AddScoped<IMvpRabbitMQConsumerAsync<UpdateCustomerRequest>, UpdateCustomerConsumerAsync>();
            services.AddScoped<IMvpRabbitMQConsumerAsync<DeleteCustomerRequest>, DeleteCustomerConsumerAsync>();
            return services;
        }

        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyHostedService(this IServiceCollection services)
        {
            services.AddMvp24HoursHostedService((e) =>
            {
                var createConsumer = ServiceProviderHelper.GetService<IMvpRabbitMQConsumerAsync<CreateCustomerRequest>>();
                createConsumer?.Consume();

                var updateConsumer = ServiceProviderHelper.GetService<IMvpRabbitMQConsumerAsync<UpdateCustomerRequest>>();
                updateConsumer?.Consume();

                var deteleConsumer = ServiceProviderHelper.GetService<IMvpRabbitMQConsumerAsync<DeleteCustomerRequest>>();
                deteleConsumer?.Consume();
            });
            return services;
        }


    }
}
