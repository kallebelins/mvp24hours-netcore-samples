namespace $safeprojectname$.ValueObjects.Customers
{
    public class CustomerQuery
    {
        public string Name { get; set; }
        public bool? Active { get; set; }
    }
}
