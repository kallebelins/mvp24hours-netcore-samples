using AutoMapper;
using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Mappings;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class UpdateCustomerRequest : MessageRequest, IMapFrom<Customer>
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string CellPhone { get; set; }
        public string Email { get; set; }
        public string Note { get; set; }
        public bool Active { get; set; }

        public virtual void Mapping(Profile profile)
        {
            profile.CreateMap<UpdateCustomerRequest, Customer>();
        }
    }
}
