using AutoMapper;
using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Mappings;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class GetByIdCustomerResponse : GetByCustomerResponse, IMapFrom<Customer>
    {
        public string CellPhone { get; set; }
        public string Email { get; set; }
        public string Note { get; set; }

        public override void Mapping(Profile profile)
        {
            profile.CreateMap<Customer, GetByIdCustomerResponse>();
        }
    }
}
