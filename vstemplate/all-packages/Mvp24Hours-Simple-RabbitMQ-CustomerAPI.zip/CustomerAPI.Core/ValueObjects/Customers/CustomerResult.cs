using AutoMapper;
using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Mappings;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class CustomerResult : IMapFrom<Customer>
    {
        public int Id { get; set; }
        public DateTime Created { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }

        public virtual void Mapping(Profile profile)
        {
            profile.CreateMap<Customer, CustomerResult>();
            profile.CreateMap<List<Customer>, List<CustomerResult>>();
        }
    }
}
