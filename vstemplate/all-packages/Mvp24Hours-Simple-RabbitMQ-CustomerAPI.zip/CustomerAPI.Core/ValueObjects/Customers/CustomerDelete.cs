namespace $safeprojectname$.ValueObjects.Customers
{
    public class CustomerDelete
    {
        public int Id { get; set; }
    }
}
