using $ext_safeprojectname$.Core.ValueObjects.Customers;
using Mvp24Hours.Infrastructure.RabbitMQ;

namespace $safeprojectname$.Brokers.Producers
{
    public class UpdateCustomerProducer : MvpRabbitMQProducer<UpdateCustomerRequest>
    {
    }
}
