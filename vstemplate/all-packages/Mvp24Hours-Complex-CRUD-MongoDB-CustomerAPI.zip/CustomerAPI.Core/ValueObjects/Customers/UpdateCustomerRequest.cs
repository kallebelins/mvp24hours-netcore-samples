using AutoMapper;
using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Mappings;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class UpdateCustomerRequest : IMapFrom<Customer>
    {
        public string Name { get; set; }
        public string Note { get; set; }

        public virtual void Mapping(Profile profile)
        {
            profile.CreateMap<UpdateCustomerRequest, Customer>();
        }
    }
}
