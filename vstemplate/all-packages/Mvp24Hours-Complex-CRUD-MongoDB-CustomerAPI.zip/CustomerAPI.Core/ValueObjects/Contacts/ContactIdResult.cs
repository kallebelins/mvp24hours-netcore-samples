using AutoMapper;
using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Mappings;

namespace $safeprojectname$.ValueObjects.Contacts
{
    public class ContactIdResult : ContactResult, IMapFrom<Contact>
    {
        public string Id { get; set; }

        public override void Mapping(Profile profile)
        {
            profile.CreateMap<Contact, ContactIdResult>()
                .ForMember(x => x.Created, opt => opt.MapFrom(y => y.Created));
        }
    }
}
