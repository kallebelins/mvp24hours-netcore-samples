using $safeprojectname$.Entities;
using Mvp24Hours.Core.Contract.Domain.Specifications;
using System;
using System.Linq.Expressions;

namespace $safeprojectname$.Specifications.Customers
{
    /// <summary>
    /// 
    /// </summary>
    public class CustomerIsPropectSpec : ISpecificationQuery<Customer>
    {
        public Expression<Func<Customer, bool>> IsSatisfiedByExpression => x => x.Note.Contains("prospect", StringComparison.InvariantCultureIgnoreCase);
    }
}
