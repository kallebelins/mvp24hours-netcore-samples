using AutoMapper;
using $safeprojectname$.Entities;
using $safeprojectname$.Enums;
using Mvp24Hours.Core.Contract.Mappings;
using System;

namespace $safeprojectname$.ValueObjects.Contacts
{
    public class GetByIdContactResponse : GetByContactResponse, IMapFrom<Contact>
    {
        public int Id { get; set; }

        public override void Mapping(Profile profile)
        {
            profile.CreateMap<Contact, GetByIdContactResponse>()
                .ForMember(x => x.Created, opt => opt.MapFrom(y => y.Created));
        }
    }
}
