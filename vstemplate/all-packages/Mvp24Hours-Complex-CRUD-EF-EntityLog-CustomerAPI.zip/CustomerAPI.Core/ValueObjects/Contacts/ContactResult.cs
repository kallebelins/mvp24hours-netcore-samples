using AutoMapper;
using $safeprojectname$.Entities;
using $safeprojectname$.Enums;
using Mvp24Hours.Core.Contract.Mappings;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.ValueObjects.Contacts
{
    public class ContactResult : IMapFrom<Contact>
    {
        public DateTime Created { get; set; }
        public DateTime? Modified { get; set; }
        public ContactType Type { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }

        public virtual void Mapping(Profile profile)
        {
            profile.CreateMap<Contact, ContactResult>()
                .ForMember(x => x.Created, opt => opt.MapFrom(y => y.Created));
            profile.CreateMap<List<Contact>, List<ContactResult>>();
        }
    }
}
