using $safeprojectname$.Enums;
using Mvp24Hours.Core.Entities;
using System;
using System.Text.Json.Serialization;

namespace $safeprojectname$.Entities
{
    public class Contact : EntityBaseLog<Contact, int, string>
    {
        [JsonIgnore]
        public int CustomerId { get; set; }
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public ContactType Type { get; set; }
        public string Description { get; set; }
        public bool Active { get; set; }

        public Customer Customer { get; set; }
    }
}
