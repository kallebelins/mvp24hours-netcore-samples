using Mvp24Hours.Core.Entities;
using System.Collections.Generic;

namespace $safeprojectname$.Entities
{
    public class Customer : EntityBaseLog<Contact, int, string>
    {
        public string Name { get; set; }
        public string Note { get; set; }
        public bool Active { get; set; }

        public ICollection<Contact> Contacts { get; set; }
    }
}
