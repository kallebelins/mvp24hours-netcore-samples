namespace $safeprojectname$.Enums
{
    public enum ContactType
    {
        CellPhone,
        HomePhone,
        CommercialPhone,
        Email,
        Other
    }
}
