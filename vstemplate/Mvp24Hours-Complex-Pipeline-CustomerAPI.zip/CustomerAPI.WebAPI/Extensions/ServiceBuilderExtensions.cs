using $ext_safeprojectname$.Application.Logic;
using $ext_safeprojectname$.Core.Contract.Logic;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Extensions
{
    /// <summary>
    /// 
    /// </summary>
    public static class ServiceBuilderExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        public static IServiceCollection AddMyServices(this IServiceCollection services)
        {
            services.AddScoped<ICustomerService, CustomerService>();
            return services;
        }
    }
}
