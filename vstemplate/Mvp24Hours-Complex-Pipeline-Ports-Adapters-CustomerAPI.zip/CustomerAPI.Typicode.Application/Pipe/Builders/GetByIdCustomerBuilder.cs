using $ext_safeprojectname$.Core.Contract.Pipe.Builders;
using $safeprojectname$.Pipe.Operations.Customers;
using Mvp24Hours.Core.Contract.Infrastructure.Pipe;

namespace $safeprojectname$.Pipe.Builders
{
    public class GetByIdCustomerBuilder : IGetByIdCustomerBuilder
    {
        public IPipelineAsync Builder(IPipelineAsync pipeline) => pipeline
            .Add<GetCustomerClientStep>()
            .Add<GetByIdCustomerMapperResponseStep>();
    }
}
