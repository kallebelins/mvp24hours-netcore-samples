using $safeprojectname$.Enums;

namespace $safeprojectname$.ValueObjects.Customers
{
    public class GetByIdContactResponse
    {
        public ContactType Type { get; set; }
        public string Description { get; set; }
    }
}
